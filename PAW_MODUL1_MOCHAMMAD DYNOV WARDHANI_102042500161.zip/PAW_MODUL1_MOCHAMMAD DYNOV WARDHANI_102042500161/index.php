<?php
// Data Produk Array PHP
$products = [
    [
        'nama' => 'Smartphone Flagship X',
        'kategori' => 'SMARTPHONE',
        'harga' => 12500000,
        'stok' => 8
    ],
    [
        'nama' => 'Mechanical Keyboard Wireless',
        'kategori' => 'AKSESORIS',
        'harga' => 850000,
        'stok' => 15
    ],
    [
        'nama' => 'Smartwatch Fitness Tracker',
        'kategori' => 'WEARABLE',
        'harga' => 1450000,
        'stok' => 0
    ],
    [
        'nama' => 'Monitor Gaming 144Hz 27 Inch',
        'kategori' => 'MONITOR',
        'harga' => 3200000,
        'stok' => 5
    ],
    [
        'nama' => 'USB-C Hub Multiport 7-in-1',
        'kategori' => 'AKSESORIS',
        'harga' => 350000,
        'stok' => 20
    ],
    [
        'nama' => 'Headphone ANC Noise Cancelling',
        'kategori' => 'AUDIO',
        'harga' => 2100000,
        'stok' => 0
    ]
];

$total_produk = count($products);
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cia Store - Katalog Produk</title>
    <!-- Menghubungkan ke file CSS eksternal -->
    <link rel="stylesheet" href="style.css">
</head>
<body>

    <header>
        <div class="logo">Cia Store</div>
        <nav>
            <a href="#">Home</a>
            <a href="#">Products</a>
            <a href="#">About</a>
        </nav>
    </header>

    <div class="container">
        <section class="hero">
            <span>CIA STORE</span>
            <h1>Simple Tech Store.</h1>
            <p>Temukan berbagai perangkat dan aksesoris teknologi untuk kebutuhanmu.</p>
            <a href="#katalog" class="btn-hero">Lihat Produk</a>
        </section>

        <div class="catalog-header" id="katalog">
            <div class="title-group">
                <span>OUR PRODUCTS</span>
                <h2>Katalog Produk</h2>
            </div>
            <div class="total-badge">
                Total Produk: <?php echo $total_produk; ?>
            </div>
        </div>

        <div class="product-grid">
            <?php 
            foreach ($products as $product): 
                $harga_normal = $product['harga'];
                $diskon_persen = 0;
                $harga_akhir = $harga_normal;

                if ($harga_normal >= 1000000) {
                    $diskon_persen = 10;
                    $harga_akhir = $harga_normal - ($harga_normal * ($diskon_persen / 100));
                }

                $is_available = $product['stok'] > 0;
            ?>

                <div class="card">
                    <div>
                        <div class="card-header">
                            <?php echo $product['kategori']; ?>
                            <?php if ($diskon_persen > 0): ?>
                                <span class="discount-tag">DISKON <?php echo $diskon_persen; ?>%</span>
                            <?php endif; ?>
                        </div>

                        <div class="card-title"><?php echo $product['nama']; ?></div>

                        <div class="price-section">
                            <?php if ($diskon_persen > 0): ?>
                                <div class="original-price">Rp<?php echo number_format($harga_normal, 0, ',', '.'); ?></div>
                            <?php endif; ?>
                            <div class="final-price">Rp<?php echo number_format($harga_akhir, 0, ',', '.'); ?></div>
                        </div>
                    </div>

                    <div>
                        <div class="stock-section">
                            <span>Stok: <?php echo $product['stok']; ?></span>
                            <?php if ($is_available): ?>
                                <span class="badge-tersedia">Tersedia</span>
                            <?php else: ?>
                                <span class="badge-habis">Stok Habis</span>
                            <?php endif; ?>
                        </div>

                        <?php if ($is_available): ?>
                            <button class="btn-buy">Beli Sekarang</button>
                        <?php else: ?>
                            <button class="btn-buy" disabled>Stok Habis</button>
                        <?php endif; ?>
                    </div>
                </div>

            <?php endforeach; ?>
        </div>
    </div>

    <footer>
        &copy; <?php echo date('Y'); ?> Cia Store. All rights reserved.
    </footer>

</body>
</html>